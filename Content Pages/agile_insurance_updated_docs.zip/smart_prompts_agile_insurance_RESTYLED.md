# Smart Prompts – Agile Insurance Brokers Website

## Stage 1: Setup

- [ ] Scaffold project using Next.js + Tailwind CSS
- [ ] Configure layout, routing, and branding theme

## Stage 2: Page Creation & Routing

- [ ] Create pages: Home, About (with subpages), Contact, Clients & Partners
- [ ] Embed `/about/services`, `/about/products`, `/about/team` under About Us
- [ ] Ensure dropdown navigation works

## Stage 3: Homepage

- [ ] Create homepage with intro, mission, vision, values
- [ ] Use `homepage.md` as content source

## Stage 4: About Us Page

- [ ] Build About Us main page
- [ ] Insert internal links to Services, Products, and Team subpages

## Stage 5: Services Page

- [ ] Create subpage `/about/services`
- [ ] Use content from `our_services.md`

## Stage 6: Products Page

- [ ] Create subpage `/about/products`
- [ ] Use content from `our_products.md`

## Stage 7: Team Page

- [ ] Create subpage `/about/team`
- [ ] Use content from `our_team.md`

## Stage 8: Partners & Clients Page

- [ ] Create standalone page `/clients`
- [ ] Populate from `our_partners_and_clients.md`

## Stage 9: Contact Page

- [ ] Create Contact page with static info and location

## Security

- [ ] Apply OWASP Top 10 guidelines
- [ ] Sanitize links and markdown inputs
